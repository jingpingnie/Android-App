package com.example.niejingping.iotlab5;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.dueeeke.videocontroller.StandardVideoController;
import com.dueeeke.videoplayer.player.IjkVideoView;
import com.dueeeke.videoplayer.player.PlayerConfig;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import cn.jzvd.JZVideoPlayerStandard;


public class VideoActivity extends AppCompatActivity {
    public final static String TAG = "VideoActivity";
    @BindView(R.id.player) JZVideoPlayerStandard jzvdStd;
    @BindView(R.id.ij_player)
    IjkVideoView ijkVideoView;
    private Context mContext;
    private Unbinder unbinder;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        unbinder = ButterKnife.bind(this);
        mContext = this;
        //initPlayer();
        initIJPlayer();
    }

    private void initIJPlayer() {
        String url = this.getIntent().getExtras().getString("URL");
        //设置视频地址
        ijkVideoView.setUrl(url);
        Log.e("URL",url);
        //ijkVideoView.setUrl("https://raw.githubusercontent.com/jingpingnie/IoTFinalProject/master/C1sPlW0roQS.mp4");
        ijkVideoView.setTitle("网易公开课"); //设置视频标题
        StandardVideoController controller = new StandardVideoController(this);
        ijkVideoView.setVideoController(controller); //设置控制器，如需定制可继承BaseVideoController
        //开始播放，不调用则不自动播放

        //高级设置（可选，须在start()之前调用方可生效）
        PlayerConfig playerConfig = new PlayerConfig.Builder()
                .enableCache() //启用边播边缓存功能
                .autoRotate() //启用重力感应自动进入/退出全屏功能
                .enableMediaCodec()//启动硬解码，启用后可能导致视频黑屏，音画不同步
                .usingSurfaceView() //启用SurfaceView显示视频，不调用默认使用TextureView
                .savingProgress() //保存播放进度
                .disableAudioFocus() //关闭AudioFocusChange监听
                .setLooping() //循环播放当前正在播放的视频
                .build();
        ijkVideoView.setPlayerConfig(playerConfig);
        ijkVideoView.start();
    }

    private void initPlayer() {
        //String url = this.getIntent().getExtras().getString("URL");
        jzvdStd.setUp("https://raw.githubusercontent.com/jingpingnie/IoTFinalProject/master/C1sPlW0roQS.mp4",
                JZVideoPlayerStandard.SCREEN_LAYOUT_NORMAL, "");
        //jzvdStd.thumbImageView.set("http://p.qpic.cn/videoyun/0/2449_43b6f696980311e59ed467f22794e792_1/640");
        //jzvdStd.thumbImageView.callOnClick();
        jzvdStd.postDelayed(new Runnable() {
            @Override
            public void run() {
                jzvdStd.startVideo();
            }
        }, 500);
    }


    @Override
    protected void onPause() {
        super.onPause();
        ijkVideoView.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ijkVideoView.resume();
    }

    @Override
    protected void onDestroy() {
        ijkVideoView.release();
        unbinder.unbind();
        super.onDestroy();
    }


    @Override
    public void onBackPressed() {
        if (!ijkVideoView.onBackPressed()) {
            super.onBackPressed();
        }
    }
    public static void startAction(Context mContext, String url) {
        Intent itt = new Intent(mContext, VideoActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("URL", url);
        itt.putExtras(bundle);
        mContext.startActivity(itt);
    }

}
