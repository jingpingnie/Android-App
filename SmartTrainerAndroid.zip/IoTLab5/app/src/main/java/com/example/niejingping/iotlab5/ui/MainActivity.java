package com.example.niejingping.iotlab5.ui;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.niejingping.iotlab5.Client;
import com.example.niejingping.iotlab5.R;
import com.example.niejingping.iotlab5.VideoActivity;
import com.example.niejingping.iotlab5.bean.RequestVideoData;
import com.example.niejingping.iotlab5.net.ApiManager;

import java.util.ArrayList;
import java.util.Locale;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


public class MainActivity extends AppCompatActivity {
    private Context mContext;
    ImageButton openMic;
    TextView showVoiceText, response;
    EditText editAddress, editPort;
    Button btnConnect, btnClear, setBut;
    final int REQ_CODE_SPEECH_OUTPUT = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_main);
        initWidget();
        requestPermission();
    }


    private void initWidget() {
        showVoiceText = (TextView) findViewById(R.id.Text1);
        openMic = (ImageButton) findViewById(R.id.btnSpeak);
        editAddress = (EditText) findViewById(R.id.addressEditText);
        editPort = (EditText) findViewById(R.id.portEditText);
        btnConnect = (Button) findViewById(R.id.connectButton);
        btnClear = (Button) findViewById(R.id.clearButton);
        setBut = (Button) findViewById(R.id.SetButton);
        response = (TextView) findViewById(R.id.responseTextView);

        openMic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnToOpenMic();
            }
        });

        btnConnect.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                //                order.getText().toString();
                Client myClient = new Client(
                        editAddress.getText().toString(),
                        80,
                        showVoiceText.getText().toString(),
                        response);
                myClient.execute();
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                response.setText("");
                showVoiceText.setText("");
                //getVideoUrl();
            }
        });
        setBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getVideoUrl();
            }
        });
    }

    private void requestPermission() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager
                .PERMISSION_GRANTED) { //表示未授权时
            //进行授权
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 1);

        }
    }

    /**
     * 权限申请返回结果
     *
     * @param requestCode  请求码
     * @param permissions  权限数组
     * @param grantResults 申请结果数组，里面都是int类型的数
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[]
            grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) { //同意权限申请
                    btnToOpenMic();
                    Toast.makeText(this, "Permission Success", Toast.LENGTH_SHORT).show();
                } else { //拒绝权限申请
                    Toast.makeText(this, "Permission Declined", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }

    private void btnToOpenMic() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hi, speak now...");

        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_OUTPUT);
        } catch (ActivityNotFoundException tim) {
            //
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case REQ_CODE_SPEECH_OUTPUT: {
                    if (resultCode == RESULT_OK && null != data) {
                        ArrayList<String> voiceInText = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                        showVoiceText.setText(voiceInText.get(0));
                    }
                    break;
                }
            }
        } else {

        }

    }


    public void getVideoUrl() {



        RequestVideoData bean = new RequestVideoData(showVoiceText.getText().toString(), "professional video");

        //开始登录
        ApiManager.getInstance()
                .getVideoApi()
                .getVideoApi(bean)


                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(final String responseBean) {
                        response.setText(responseBean);
                        Toast.makeText(mContext, "URL Received", Toast.LENGTH_SHORT).show();
                        showVoiceText.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                VideoActivity.startAction(mContext, responseBean);
                            }
                        }, 1000);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        response.setText(throwable.toString());
                        Log.e("E", throwable.toString());
                    }
                });
    }


}
