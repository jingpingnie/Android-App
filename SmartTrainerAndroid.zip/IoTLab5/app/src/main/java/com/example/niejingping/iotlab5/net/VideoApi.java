package com.example.niejingping.iotlab5.net;


import com.example.niejingping.iotlab5.bean.RequestVideoData;

import io.reactivex.Observable;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * 类名: {@link VideoApi}

 */
public interface VideoApi {
    /**
     * 登录接口
     */
    @POST("/")
    Observable<String> getVideoApi(@Body RequestVideoData videoApi);
}
