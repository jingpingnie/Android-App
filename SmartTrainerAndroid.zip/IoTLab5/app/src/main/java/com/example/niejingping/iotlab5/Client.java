package com.example.niejingping.iotlab5;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;

public class Client extends AsyncTask<String, String, String> {

    String dstAddress;
    int dstPort;
    String response = "";
    TextView textResponse;
    String order;

    public Client(String addr, int port, String order, TextView textResponse) {
        dstAddress = addr;
        dstPort = port;
        this.order = order;
        this.textResponse = textResponse;
    }

    @Override
    protected String doInBackground(String... params) {
        OutputStream out = null;
        String response1 = "";

        try {
            URL url = new URL(dstAddress);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.connect();
            out = new BufferedOutputStream(urlConnection.getOutputStream());


            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, "UTF-8"));
            Log.v("doinbackground data", order);
            writer.write(order);
            writer.flush();
            writer.close();
            out.close();


            urlConnection.connect();

            String line;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            while ((line = bufferedReader.readLine()) != null) {
                Log.v("uiyfiu", line);
                response1 += line;
            }
            urlConnection.disconnect();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Log.e("response", response1);
        return response1;

    }

    @Override
    protected void onPostExecute(String result) {
        textResponse.setText(response);
        super.onPostExecute(result);
    }

}
