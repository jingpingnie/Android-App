package com.example.niejingping.iotlab5.net;


import android.support.annotation.NonNull;
import android.util.Log;

import com.example.niejingping.iotlab5.net.convert.CustomGsonConverterFactory;
import com.example.niejingping.iotlab5.net.convert.CustomInterceptor;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 类名: {@link ApiManager}

 */
public class ApiManager {
    public static ApiManager sApiManager;
    private VideoApi mVedioApi;

    private ApiManager() {
    }

    public static ApiManager getInstance() {
        if (sApiManager == null) {
            synchronized (ApiManager.class) {
                if (sApiManager == null) {
                    sApiManager = new ApiManager();
                }
            }
        }
        return sApiManager;
    }

    public OkHttpClient mClient = new OkHttpClient.Builder()
            .addInterceptor(new CustomInterceptor())
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build();


    @NonNull
    public Retrofit getRetrofit() {
        String baseUrl = "http://3.16.31.183:80";
        Log.e("url", baseUrl);
        return new Retrofit.Builder()
                .client(mClient)
                .baseUrl(baseUrl)
                .addConverterFactory(CustomGsonConverterFactory.create())
//                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
    }


    public VideoApi getVideoApi() {
        if (mVedioApi == null) {
            mVedioApi = getRetrofit().create(VideoApi.class);
        }
        return mVedioApi;
    }
}
