package com.example.niejingping.iotlab5.bean;

/**
 * Created by MouShao on 2018/11/18.
 */

public class ResponseVideoData {
    private String data;

    public ResponseVideoData(String data) {
        this.data = data;
    }

    public String getData() {
        return data == null ? "" : data;
    }
}
